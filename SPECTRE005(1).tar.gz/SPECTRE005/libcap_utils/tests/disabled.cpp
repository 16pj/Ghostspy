#include <stdio.h>

int main(int argc, const char* argv[]){
	fprintf(stderr, "Tests has been disabled, make sure cppunit is installed.\n");
	return 1;
}

# Consumers

In DPMI measurement points MP produce packet traces, often sent live
as measurement streams. Consumers takes either an offline tracefile or
a live stream and analyze the data in some way.

For instance, a consumer might look at the packets to determine the
current bitrate across a MP.

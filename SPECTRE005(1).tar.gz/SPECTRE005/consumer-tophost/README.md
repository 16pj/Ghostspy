# consumer-tophost

Reads a DPMI stream, prints out the top tuple every T time unit.

